# PLATEAU-TouchDesigner-Plugin

PLATEAU TouchDesigner Pluginは、TouchDesignerで[PLATEAU](https://www.mlit.go.jp/plateau/)の3D都市モデルデータを簡単に扱えるようにするためのツールです。
そのため、利用にはTouchDesignerのアプリ本体が必要です。リポジトリページにある動作環境をご覧頂き環境をご準備の上以下の方法でご利用ください。

![Cover Image](resources/cover.png)
